
// Handle playing audio
// This is minimal implementation! 
const canvas = document.querySelector('canvas')
const ctx = canvas.getContext('2d')

const centerX = canvas.width / 2
const centerY = canvas.height / 2
const radius = canvas.width / 5

let analyser
let frequencyArray

function startAudio() {
  // Create an Audio instance 
  const audio = new Audio()
  // Make a new Audio Context
  const audioContext = new (window.AudioContext || window.webkitAudioContext)()
  // Set the src to a sound file
  audio.src = 'bird-whistling-a.wav'
  // Play the audio

	// Create an audio analyser
	console.log()
  analyser = audioContext.createAnalyser()
  // Create an audio source
  const source = audioContext.createMediaElementSource(audio)
  // Connect the source to the analyser
  source.connect(analyser)
  // Connect the analyser to the audio context
  analyser.connect(audioContext.destination)
  // Get an array of audio data from the analyser
  frequencyArray = new Uint8Array(analyser.frequencyBinCount)

  audio.play()
	render()
}

function render() {
  // Clear the screen
	ctx.clearRect(0, 0, 300, 300)

  // Draw a circle in the center
  // ctx.beginPath()
  // ctx.arc(centerX, centerY, radius, 0, 2 * Math.PI)
  // ctx.strokeStyle = 'red'
  // ctx.stroke()

  // We're going to draw lines coming from the center 
  // of a circle. We need to divide the circle into degree steps

  // Get the frequency array data
  analyser.getByteFrequencyData(frequencyArray)

  // draw_1(frequencyArray, ctx)
  // draw_2(frequencyArray, ctx)
  // draw_3(frequencyArray, ctx)
  // draw_4(frequencyArray, ctx)
  draw_5(frequencyArray, ctx)
  
	requestAnimationFrame(render)
}

const playButton = document.querySelector('#button-play')

// You can't play audio without some user interaction
playButton.addEventListener('click', () => startAudio())












// Draw circle 
let color_increment = 0
function draw_5(arr, ctx) {
  const PI2 = Math.PI * 2
  // find the n largest values 
  let max_val = 0
  ctx.beginPath()

  arr.forEach((val, i) => {
    max_val = Math.max(val, max_val)
    if (i % 32 === 0) {
      const size = max_val / 255 * 300
      ctx.moveTo(0, 0)
      ctx.arc(0, 0, size, 0, PI2)
      ctx.moveTo(0, 300)
      ctx.arc(0, 300, size, 0, PI2)
      ctx.moveTo(300, 300)
      ctx.arc(300, 300, size, 0, PI2)
      ctx.moveTo(300, 0)
      ctx.arc(300, 0, size, 0, PI2)

    }
  })
  color_increment += 1
  color_increment = color_increment % 360

  ctx.strokeStyle = `hsl(${})`
  ctx.lineWidth = 1
  ctx.stroke()
  ctx.closePath()
}














// Draw circle 
function draw_4(arr, ctx) {
  const PI2 = Math.PI * 2
  // find the n largest values 
  let max_val = 0

  ctx.beginPath()

  arr.forEach((val, i) => {
    max_val = Math.max(val, max_val)
    if (i % 32 === 0) {
      const size = max_val / 255 * 300
      ctx.moveTo(0, 0)
      ctx.arc(0, 0, size, 0, PI2)
      ctx.moveTo(0, 300)
      ctx.arc(0, 300, size, 0, PI2)
      ctx.moveTo(300, 300)
      ctx.arc(300, 300, size, 0, PI2)
      ctx.moveTo(300, 0)
      ctx.arc(300, 0, size, 0, PI2)

    }
  })
  ctx.strokeStyle = '#000'
  ctx.lineWidth = 1
  ctx.stroke()
  ctx.closePath()
}











// Draw boxes 
function draw_3(arr, ctx) {
  ctx.beginPath()

  // find the n largest values 
  let max_val = 0
  arr.forEach((val, i) => {
    max_val = Math.max(val, max_val)
    if (i % 8 === 0) {
      const size = max_val / 255 * 300
      ctx.rect(0, 0, size, size)
      ctx.rect(300 - size, 0, size, size)
      ctx.rect(300 - size, 300 - size, size, size)
      ctx.rect(0, 300 - size, size, size)
    }
  })
  ctx.strokeStyle = '#000'
  ctx.lineWidth = 1
  ctx.stroke()
  ctx.closePath()
}









// Draw some boxes from the upper left
// Challenge draw boxes from the out from each of the four corners
// NOTE! To place a box in the upper right the x value will need to 
// 300 - size. The same applies to the y value for boxes on the 
// lower two corners
// Stretch goal: draw boxes in a three by three grid
// On Testing drawing that many boxes slowed the computer down try 
// dividing the 1024 rectangle between the four corners
function draw_2(arr, ctx) {
  ctx.beginPath()
  arr.forEach((val, i) => {
    const size = val / 255 * 300
    ctx.rect(0, 0, size, size)
  })
  ctx.strokeStyle = '#000'
  ctx.lineWidth = 1
  ctx.stroke()
  ctx.closePath()
}
















function draw_1(frequencyArray, ctx) {
  const bars = 200 // Number of steps
  const step = Math.PI * 2 / bars // degrees for each step
  // -------------------------------------------------------
  // Loop over all values in the array
	frequencyArray.forEach((f, i) => {
    // Calculate the length of a line by the value in the array
    const barLength = frequencyArray[i] * 0.5
    // Find the x and y of the start and end of the line
    const x1 = (Math.cos(step * i) * radius) + centerX
    const y1 = (Math.sin(step * i) * radius) + centerY
    const x2 = (Math.cos(step * i) * (radius + barLength)) + centerX
    const y2 = (Math.sin(step * i) * (radius + barLength)) + centerY
    // Move to the starting point
    ctx.moveTo(x1, y1)
    // Draw a line to the end point
    ctx.lineTo(x2, y2)
  })

  // Stroke all lines
	ctx.stroke()
  // ---------------------------------------------------------
}